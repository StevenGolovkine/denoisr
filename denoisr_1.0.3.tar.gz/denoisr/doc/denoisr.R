## ---- include = FALSE---------------------------------------------------------
knitr::opts_chunk$set(
  collapse = TRUE,
  comment = "#>"
)

## ----setup, warning=FALSE, message=FALSE--------------------------------------
# Load packages
library(denoisr)
library(dplyr)
library(funData)
library(ggplot2)
library(reshape2)

## ----load_data----------------------------------------------------------------
# Load data
data("canadian_temperature_daily")

## ----convert_funData----------------------------------------------------------
# Convert list to funData object
data_fd <- list2funData(canadian_temperature_daily)

## ----plot_data, fig.height=4.35, fig.width=7----------------------------------
# Plot of the data
autoplot(data_fd) + 
  labs(title = 'Daily Temperature Data',
       x = 'Normalized Day of Year',
       y = 'Temperature in °C') +
  theme_minimal()

## ----smooth_data--------------------------------------------------------------
# Smooth the data
smooth_data <- smooth_curves(canadian_temperature_daily, 
                             t0_list = 0.5, 
                             k0_list = 5)

## ----plot_data2, fig.height=4.35, fig.width=7---------------------------------
# Plot of the smoothed data
smooth_data_fd <- list2funData(smooth_data$smooth)
autoplot(smooth_data_fd) +
  labs(title = 'Smooth Daily Temperature Data',
       x = 'Normalized Day of Year',
       y = 'Temperature in °C') +
  theme_minimal()

## ----plot_data3, fig.height=4.35, fig.width=7---------------------------------
# Plot one realisation of the smoothed data
montreal <- tibble(t = canadian_temperature_daily$Montreal$t,
                   Data = canadian_temperature_daily$Montreal$x,
                   Smooth = smooth_data$smooth$Montreal$x) %>% 
  reshape2::melt(id = 't')
ggplot(montreal, aes(x = t, y = value, color = variable)) +
  geom_line() +
  labs(title = 'Example of Montreal',
       x = 'Normalized Day of Year',
       y = 'Temperature in °C',
       color = '') +
  theme_minimal()


## ----compute_mean-------------------------------------------------------------
# Compute the mean curve
mean_curve <- estimate_mean(canadian_temperature_daily,
                            U = seq(0, 1, length.out = 501),
                            b = smooth_data$parameter$b)

## ----plot_mean, fig.height=4.35, fig.width=7----------------------------------
mean_curve_plot <- tibble(t = seq(0, 1, length.out = 501), x = mean_curve)
autoplot(data_fd) +
  geom_line(data = mean_curve_plot, mapping = aes(x = t, y = x, group = NULL), col = 'red', size = 2) +
  labs(title = 'Daily Temperature Data',
       x = 'Normalized Day of Year',
       y = 'Temperature in °C') +
  theme_minimal()

## ----compute_covariance-------------------------------------------------------
# Compute the covariance surface
U <- seq(0, 1, length.out = 101)
cov_surface <- estimate_covariance(canadian_temperature_daily,
                                   U = U,
                                   b = smooth_data$parameter$b,
                                   h = 0.05)

## ----plot_covariance, fig.height=5, fig.width=5, fig.align='center'-----------
cov_surface_plot <- tibble(expand.grid(U, U), C = as.vector(cov_surface))
ggplot(cov_surface_plot) + 
  geom_contour_filled(aes(x = Var1, y = Var2, z = C)) + 
  labs(title = 'Covariance surface of daily temperature data',
       x = '',
       y = '',
       fill = 'Level') +
  theme_minimal()

## ----load_brownian, warning=FALSE, message=FALSE------------------------------
# Simulate some data
set.seed(42)
fractional_brownian <- generate_fractional_brownian(N = 100, M = 350, 
                                                    H = 0.5, sigma = 0.05)

## ----smooth_data_brown--------------------------------------------------------
# Smooth the data
smooth_data <- smooth_curves(fractional_brownian, 
                             t0_list = 0.5, 
                             k0_list = 14)

## ----estimate_H_brow----------------------------------------------------------
# Estimation of the Hurst coefficient
print(smooth_data$parameter$H0)

## ----plot_brown, fig.height=4.35, fig.width=7---------------------------------
# Plot a particular observation
obs <- tibble(t = fractional_brownian[[1]]$t,
              Noisy = fractional_brownian[[1]]$x,
              Truth = fractional_brownian[[1]]$x_true,
              Smooth = smooth_data$smooth[[1]]$x) %>% 
  reshape2::melt(id = 't')
ggplot(obs, aes(x = t, y = value, color = variable)) +
  geom_line() +
  labs(title = 'Fractional brownian motion',
       x = 'Normalized time',
       y = 'Value',
       color = '') +
  theme_minimal()

## ----mean_frac_brown----------------------------------------------------------
# Compute the mean curve
mean_curve <- estimate_mean(fractional_brownian,
                            U = seq(0, 1, length.out = 100),
                            b = smooth_data$parameter$b)

## ----plot_mean_frac_brown, fig.height=4.35, fig.width=7-----------------------
data_fd <- list2irregFunData(fractional_brownian)
mean_curve_plot <- tibble(t = seq(0, 1, length.out = 100), x = mean_curve)
autoplot(data_fd) +
  geom_line(data = mean_curve_plot, mapping = aes(x = t, y = x, group = NULL), col = 'red', size = 2) +
  labs(title = 'Fractional brownian motion',
       x = 'Normalized time',
       y = 'Value') +
  theme_minimal()

## ----compute_covariance_frac_brown--------------------------------------------
# Compute the covariance surface
U <- seq(0, 1, length.out = 101)
cov_surface <- estimate_covariance(fractional_brownian,
                                   U = U,
                                   b = smooth_data$parameter$b,
                                   h = 0.05)

## ----plot_covariance_frac_brown, fig.height=5, fig.width=5, fig.align='center'----
# Show the covariance surface
cov_surface_plot <- tibble(expand.grid(U, U), C = as.vector(cov_surface))
ggplot(cov_surface_plot) + 
  geom_contour_filled(aes(x = Var1, y = Var2, z = C)) + 
  labs(title = 'Covariance surface of fractional brownian motion',
       x = '',
       y = '',
       fill = 'Level') +
  theme_minimal()

## ----load_piecewise_brownian, warning=FALSE, message=FALSE--------------------
set.seed(42)
piece_frac_brown <- generate_piecewise_fractional_brownian(N = 150, M = 350, 
                                                           H = c(0.2, 0.5, 0.8), 
                                                           sigma = 0.05)

## ----smooth_data_piecebrown---------------------------------------------------
# Smooth the data
smooth_data <- smooth_curves(piece_frac_brown, 
                             t0_list = c(0.15, 0.5, 0.85), 
                             k0_list = c(14, 14, 14))

## ----estimate H_piecebrow-----------------------------------------------------
# Estimation of the Hurst coefficient
print(smooth_data$parameter$H0)

## ----plot_piece_brown, fig.height=4.35, fig.width=7---------------------------
# Plot a particular observation
obs <- tibble(t = piece_frac_brown[[1]]$t,
              Noisy = piece_frac_brown[[1]]$x,
              Truth = piece_frac_brown[[1]]$x_true,
              Smooth = smooth_data$smooth[[1]]$x) %>% 
  reshape2::melt(id = 't')
ggplot(obs, aes(x = t, y = value, color = variable)) +
  geom_line() +
  labs(title = 'Piecewise fractional brownian motion',
       x = 'Normalized time',
       y = 'Value',
       color = '') +
  theme_minimal()

## ----mean_piece_frac_brown----------------------------------------------------
# Compute the mean curve
mean_curve <- estimate_mean(piece_frac_brown,
                            U = seq(0, 1, length.out = 100),
                            b = smooth_data$parameter$b,
                            t0_list = c(0.15, 0.5, 0.85))

## ----plot_mean_piece_frac_brown, fig.height=4.35, fig.width=7-----------------
data_fd <- list2irregFunData(piece_frac_brown)
mean_curve_plot <- tibble(t = seq(0, 1, length.out = 100), x = mean_curve)
autoplot(data_fd) +
  geom_line(data = mean_curve_plot, mapping = aes(x = t, y = x, group = NULL), col = 'red', size = 2) +
  labs(title = 'Fractional brownian motion',
       x = 'Normalized time',
       y = 'Value') +
  theme_minimal()

## ----compute_covariance_piece_frac_brown--------------------------------------
# Compute the covariance surface
U <- seq(0, 1, length.out = 101)
cov_surface <- estimate_covariance(piece_frac_brown,
                                   U = U,
                                   b = smooth_data$parameter$b,
                                   h = 0.05,
                                   t0_list = c(0.15, 0.5, 0.85))

## ----plot_covariance_piece_frac_brown, fig.height=5, fig.width=5, fig.align='center'----
# Show the covariance surface
cov_surface_plot <- tibble(expand.grid(U, U), C = as.vector(cov_surface))
ggplot(cov_surface_plot) + 
  geom_contour_filled(aes(x = Var1, y = Var2, z = C)) + 
  labs(title = 'Covariance surface of \n piecewise fractional brownian motion',
       x = '',
       y = '',
       fill = 'Level') +
  theme_minimal()

## ----load_inte_brownian, warning=FALSE, message=FALSE-------------------------
# Simulate some data
set.seed(42)
inte_fractional_brownian <- generate_integrate_fractional_brownian(N = 100, M = 350, H = 0.5, sigma = 0.025)

## ----smooth_data_inte_brown---------------------------------------------------
# Smooth the data
smooth_data <- smooth_curves_regularity(inte_fractional_brownian, 
                                        t0 = 0.5, k0 = 14)

## ----estimate_H_inte_brow-----------------------------------------------------
# Estimation of the Hurst coefficient
print(smooth_data$parameter$H0)

## ----plot_inte_brown, fig.height=4.35, fig.width=7----------------------------
# Plot a particular observation
obs <- tibble(t = inte_fractional_brownian[[1]]$t,
              Noisy = inte_fractional_brownian[[1]]$x,
              Truth = inte_fractional_brownian[[1]]$x_true,
              Smooth = smooth_data$smooth[[1]]$x) %>% 
  reshape2::melt(id = 't')
ggplot(obs, aes(x = t, y = value, color = variable)) +
  geom_line() +
  labs(title = 'Integreted Fractional brownian motion',
       x = 'Normalized time',
       y = 'Value',
       color = '') +
  theme_minimal()

## ----mean_frac_inte_brown-----------------------------------------------------
# Compute the mean curve
mean_curve <- estimate_mean(inte_fractional_brownian,
                            U = seq(0, 1, length.out = 100),
                            b = smooth_data$parameter$b)

## ----plot_mean_inte_frac_brown, fig.height=4.35, fig.width=7------------------
data_fd <- list2irregFunData(inte_fractional_brownian)
mean_curve_plot <- tibble(t = seq(0, 1, length.out = 100), x = mean_curve)
autoplot(data_fd) +
  geom_line(data = mean_curve_plot, mapping = aes(x = t, y = x, group = NULL), col = 'red', size = 2) +
  labs(title = 'Integrated fractional brownian motion',
       x = 'Normalized time',
       y = 'Value') +
  theme_minimal()

## ----compute_covariance_inte_frac_brown---------------------------------------
# Compute the covariance surface
U <- seq(0, 1, length.out = 101)
cov_surface <- estimate_covariance(inte_fractional_brownian,
                                   U = U,
                                   b = smooth_data$parameter$b,
                                   h = 0.05)

## ----plot_covariance_inte_frac_brown, fig.height=5, fig.width=5, fig.align='center'----
# Show the covariance surface
cov_surface_plot <- tibble(expand.grid(U, U), C = as.vector(cov_surface))
ggplot(cov_surface_plot) + 
  geom_contour_filled(aes(x = Var1, y = Var2, z = C)) + 
  labs(title = 'Covariance surface of integrated fractional brownian motion',
       x = '',
       y = '',
       fill = 'Level') +
  theme_minimal()

