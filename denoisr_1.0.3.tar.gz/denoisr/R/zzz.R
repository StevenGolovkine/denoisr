.onUnload <- function(libpath){
  library.dynam.unload("denoisr", libpath)
}