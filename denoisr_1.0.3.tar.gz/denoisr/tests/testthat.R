library(testthat)
library(denoisr)

test_check("denoisr")
